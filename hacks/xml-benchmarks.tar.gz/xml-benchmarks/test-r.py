#!/usr/bin/python
"""Benchmark pyRXP

This benchmark loads an XML file in pyRXP (non-Unicode!), and does a tree
walk, accumulating nodes that have a "name" attribute of "reselectApi".
"""
__author__ = 'Aaron Brady <bradya@gmail.com>'
__date__ = '2005/01/01'

def name_reselect(tupl):
	return tupl[1] and tupl[1].get('name') == 'reselectApi'

def x_find(tupl, match, matches):
	r = match(tupl)
	if r:
		matches.append(tupl[1])
	if type(tupl[2]) == type([]):
		for i in tupl[2]:
			if type(i) == type((1,)):
				x_find(i, match, matches)

def main():
	import pyRXP
	p = pyRXP.Parser()
	d = p.parse(file('test.xml').read(), ErrorOnBadCharacterEntities=0)
	matches = []
	x_find(d, name_reselect, matches)
	print matches

if __name__ == '__main__':
	main()
