#!/usr/bin/python
"""Benchmark 4DOM & minidom parsers.

This benchmark loads an XML file in one of the two parsers, and does a simple
XPath search for elements with a "name" attribute of "reselectApi".
"""
__author__ = 'Aaron Brady <bradya@gmail.com>'
__date__ = '2005/01/01'

import sys

def parse_with_4dom(filename):
	import xml.dom.ext.reader.Sax2
	reader = xml.dom.ext.reader.Sax2.Reader()
	doc = reader.fromStream(open(filename))
	return doc

def parse_with_minidom(filename):
	import xml.dom.minidom
	return xml.dom.minidom.parse(filename)

def main(*v):
	if len(v) == 1 or v[1] not in ('M', '4'):
		print >>sys.stderr, "Usage: %s <M|4>" % v[0]
		return
	if v[1] == 'M':
		parse_f = parse_with_minidom
	elif v[1] == '4':
		parse_f = parse_with_4dom
	d = parse_f('test.xml')
	import xml.xpath
	print xml.xpath.Evaluate('descendant::*[@name="reselectApi"]', d)

if __name__ == '__main__':
	main(*sys.argv)
